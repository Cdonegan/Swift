//
//  FoodItem.swift
//  FoodAPP
//
//  Created by Connor Donegan on 2/18/20.
//  Copyright © 2020 Connor Donegan. All rights reserved.
//

import Foundation



class FoodItem {
    var foodName: String?
    var foodImageName: String?
    var foodCals: Int = 0
    
}
